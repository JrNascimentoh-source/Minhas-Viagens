# Minhas Viagens

App (Android e iPhone) para anotar viagens, confirmar conclusão/pagamento, ver o calendário e gerar relatório mensal em PDF.

- **Tecnologia:** React Native + Expo (Expo Router), Supabase (login e banco de dados)
- **Login:** e-mail e senha, ou Google
- **Lembretes:** notificação local a cada 9 horas para cada viagem em aberto
- **Tema:** claro, escuro ou automático (segue o sistema)

## 1. Criar o projeto Expo e copiar estes arquivos

Requisitos: Node.js (versão LTS) e Git.

```bash
npx create-expo-app@latest minhas-viagens
cd minhas-viagens
```

Apague as pastas de exemplo do template (`app`, `components`, `constants`, `hooks`, `scripts`, se existirem) e copie para dentro do projeto o conteúdo deste pacote: `app/`, `src/`, `assets/`, `supabase/`, `app.json`, `.env`, `.env.example`, `.gitignore`. A pasta `assets/` tem o ícone do app, e o `app.json` já aponta para ele.

Instale as dependências (o `expo install` escolhe as versões compatíveis com o seu Expo):

```bash
npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill react-native-svg expo-linear-gradient expo-notifications expo-print expo-sharing expo-web-browser expo-linking expo-status-bar expo-splash-screen expo-router react-native-safe-area-context @react-navigation/bottom-tabs @expo/vector-icons
```

## 2. Configurar o Supabase

O projeto `minhas-viagens` já foi criado, com a tabela `trips` e as regras de segurança (cada usuário só vê as próprias viagens). O arquivo `supabase/migrations/` guarda o SQL para referência.

O arquivo `.env` já tem a URL e a chave pública (publishable) do projeto. Ele está no `.gitignore` e não vai para o GitHub. Quem clonar o repositório copia `.env.example` para `.env` e preenche.

### Login com Google (precisa ser feito por você)

1. No [Google Cloud Console](https://console.cloud.google.com/), crie um projeto (ou use um existente) e configure a **tela de consentimento OAuth**.
2. Em **APIs e serviços > Credenciais > Criar credenciais > ID do cliente OAuth**, escolha o tipo **Aplicativo da Web**.
3. Em **URIs de redirecionamento autorizados**, adicione:
   `https://exxrxcfuetxfdtqeokwf.supabase.co/auth/v1/callback`
4. Copie o **Client ID** e o **Client Secret**.
5. No painel do Supabase (projeto `minhas-viagens`): **Authentication > Providers > Google**. Ative e cole o Client ID e o Secret.
6. Em **Authentication > URL Configuration > Redirect URLs**, adicione:
   - `minhasviagens://**` (app instalado)
   - `exp://**` (somente para testes com Expo Go)

Os nomes dos menus podem variar um pouco, pois os painéis são atualizados com frequência.

### Cadastro por e-mail

Por padrão o Supabase exige confirmar o e-mail após o cadastro. Para testar sem isso, desative em **Authentication > Providers > Email > Confirm email**.

## 3. Rodar o app

```bash
npx expo start
```

Para testar **notificações** e o **login com Google**, o ideal é usar um *development build* e não o Expo Go:

```bash
npx expo run:android     # precisa do Android Studio
npx expo run:ios         # só em Mac, precisa do Xcode
```

Para instalar em iPhone físico é necessária uma conta Apple (Apple Developer para distribuir o app).

## 4. Subir para o GitHub

Crie um repositório vazio no GitHub (sem README) e, na pasta do projeto:

```bash
git init
git add .
git commit -m "Primeira versão do Minhas Viagens"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/minhas-viagens.git
git push -u origin main
```

Confira que o `.env` não apareceu no `git status` antes do push.

## Como o app funciona

| Etapa | O que acontece |
|---|---|
| Nova viagem | Você informa dia, valor e descrição. O app grava a hora de saída, a data e o período (manhã, tarde, noite). A viagem fica **em aberto**. |
| Lembrete | Um aviso a cada 9 h pergunta se a viagem foi concluída e se já foi paga. Tocar no aviso abre a tela de confirmação. |
| Confirmação | Só depois de confirmar que foi concluída a viagem vai para o **registro**. Se disser "ainda não", o lembrete continua. |
| Calendário | Mostra dias trabalhados, sem viagem, em aberto e futuros. Tocar em uma viagem permite confirmar, marcar como paga ou excluir. |
| Relatório | Dias trabalhados, dias não trabalhados e total recebido do mês (viagens concluídas **e pagas**), em PDF para compartilhar. |

## Estrutura

```
app/            telas (Expo Router): login, abas, nova viagem, confirmação
src/lib/        Supabase, viagens, datas, notificações, PDF
src/components/ barra de navegação, rosca, componentes de UI
src/theme/      tema claro/escuro/automático
assets/         ícone do app (iOS, Android, splash, favicon)
src/auth/       sessão e login com Google
supabase/       SQL do banco
```
