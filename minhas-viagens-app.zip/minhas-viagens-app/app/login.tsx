import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../src/auth/AuthProvider';
import { supabase } from '../src/lib/supabase';

const GOLD = '#F0B070';
const GRAD = ['#FFB04D', '#FF7A1A'] as const;
const BORDER_GRAD = ['#FF9A3D', '#A64DFF', '#3D8BFF'] as const;

function friendly(message: string): string {
  if (/invalid login credentials/i.test(message)) return 'E-mail ou senha incorretos.';
  if (/already registered/i.test(message)) return 'Este e-mail já tem cadastro. Use a aba Entrar.';
  if (/email not confirmed/i.test(message)) return 'Confirme seu e-mail pelo link que enviamos.';
  if (/password should be at least/i.test(message)) return 'A senha precisa ter pelo menos 6 caracteres.';
  return message;
}

function Field(props: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  value: string;
  onChangeText: (t: string) => void;
  placeholder: string;
  secure?: boolean;
  keyboardType?: 'default' | 'email-address';
  autoCapitalize?: 'none' | 'words';
  autoComplete?: 'email' | 'password' | 'name' | 'new-password';
}) {
  const [show, setShow] = useState(false);
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ fontSize: 12, fontWeight: '800', letterSpacing: 1.2, color: GOLD }}>{props.label}</Text>
      <View
        style={{
          height: 52,
          borderRadius: 16,
          borderWidth: 1,
          borderColor: '#2A2535',
          backgroundColor: '#17141F',
          flexDirection: 'row',
          alignItems: 'center',
          paddingLeft: 16,
        }}
      >
        <Ionicons name={props.icon} size={20} color="#9A94AB" />
        <TextInput
          value={props.value}
          onChangeText={props.onChangeText}
          placeholder={props.placeholder}
          placeholderTextColor="#9A94AB"
          secureTextEntry={props.secure && !show}
          keyboardType={props.keyboardType}
          autoCapitalize={props.autoCapitalize ?? 'none'}
          autoComplete={props.autoComplete}
          accessibilityLabel={props.label}
          style={{ flex: 1, color: '#FFFFFF', fontSize: 16, fontWeight: '600', paddingHorizontal: 12, height: 52 }}
        />
        {props.secure ? (
          <Pressable
            onPress={() => setShow((s) => !s)}
            accessibilityRole="button"
            accessibilityLabel={show ? 'Ocultar senha' : 'Mostrar senha'}
            style={{ width: 48, height: 48, alignItems: 'center', justifyContent: 'center' }}
          >
            <Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={22} color={GOLD} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

export default function Login() {
  const insets = useSafeAreaInsets();
  const { signInWithGoogle } = useAuth();
  const [signup, setSignup] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!email.trim() || password.length < 6) {
      Alert.alert('Confira os dados', 'Informe o e-mail e uma senha com pelo menos 6 caracteres.');
      return;
    }
    setBusy(true);
    try {
      if (signup) {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: name.trim() } },
        });
        if (error) throw error;
        if (!data.session) {
          Alert.alert('Confirme seu e-mail', 'Enviamos um link de confirmação. Depois de confirmar, volte e entre.');
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      }
    } catch (e: any) {
      Alert.alert('Não foi possível continuar', friendly(e?.message ?? 'Erro desconhecido'));
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    try {
      await signInWithGoogle();
    } catch (e: any) {
      Alert.alert('Login com Google', friendly(e?.message ?? 'Não foi possível entrar com o Google.'));
    } finally {
      setBusy(false);
    }
  };

  const forgot = async () => {
    if (!email.trim()) {
      Alert.alert('Esqueci minha senha', 'Digite seu e-mail no campo acima e toque novamente.');
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim());
    if (error) Alert.alert('Erro', friendly(error.message));
    else Alert.alert('Verifique seu e-mail', 'Enviamos um link para redefinir a senha.');
  };

  const tab = (label: string, active: boolean, onPress: () => void) => (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flex: 1 }}>
      {active ? (
        <LinearGradient colors={GRAD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 15, fontWeight: '800', color: '#1A1209' }}>{label}</Text>
        </LinearGradient>
      ) : (
        <View style={{ height: 46, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 15, fontWeight: '800', color: '#B9B3C9' }}>{label}</Text>
        </View>
      )}
    </Pressable>
  );

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: '#0C0912' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 20, paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }}
        keyboardShouldPersistTaps="handled"
      >
        <LinearGradient colors={BORDER_GRAD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderRadius: 30, padding: 1.5 }}>
          <View style={{ backgroundColor: '#100D18', borderRadius: 28.5, padding: 20, gap: 18 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
              <LinearGradient colors={GRAD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="navigate" size={30} color="#1A1209" />
              </LinearGradient>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 24, fontWeight: '800', color: '#FFFFFF' }}>Minhas Viagens</Text>
                <Text style={{ fontSize: 10, fontWeight: '600', letterSpacing: 1.6, color: GOLD, marginTop: 4 }}>
                  VIAGENS · PAGAMENTOS · RELATÓRIOS
                </Text>
              </View>
            </View>

            <View style={{ flexDirection: 'row', backgroundColor: '#17141F', borderRadius: 18, padding: 5, gap: 6 }}>
              {tab('Entrar', !signup, () => setSignup(false))}
              {tab('Cadastrar', signup, () => setSignup(true))}
            </View>

            {signup ? (
              <Field label="NOME" icon="person-outline" value={name} onChangeText={setName} placeholder="Seu nome" autoCapitalize="words" autoComplete="name" />
            ) : null}
            <Field label="EMAIL" icon="mail-outline" value={email} onChangeText={setEmail} placeholder="voce@email.com" keyboardType="email-address" autoComplete="email" />
            <Field label="SENHA" icon="lock-closed-outline" value={password} onChangeText={setPassword} placeholder="Mínimo 6 caracteres" secure autoComplete={signup ? 'new-password' : 'password'} />

            <Pressable onPress={submit} disabled={busy} accessibilityRole="button">
              <LinearGradient colors={GRAD} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ height: 54, borderRadius: 20, alignItems: 'center', justifyContent: 'center', opacity: busy ? 0.6 : 1 }}>
                {busy ? (
                  <ActivityIndicator color="#1A1209" />
                ) : (
                  <Text style={{ fontSize: 17, fontWeight: '800', color: '#1A1209' }}>{signup ? 'CRIAR CONTA' : 'ENTRAR'}</Text>
                )}
              </LinearGradient>
            </Pressable>

            {!signup ? (
              <Pressable onPress={forgot} accessibilityRole="button" style={{ alignSelf: 'flex-end', height: 40, justifyContent: 'center', marginTop: -10 }}>
                <Text style={{ color: '#FF9A3D', fontSize: 14, fontWeight: '800' }}>Esqueci minha senha</Text>
              </Pressable>
            ) : null}

            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ flex: 1, height: 1, backgroundColor: '#2A2535' }} />
              <Text style={{ color: '#B9B3C9', fontSize: 13, fontWeight: '600' }}>ou</Text>
              <View style={{ flex: 1, height: 1, backgroundColor: '#2A2535' }} />
            </View>

            <Pressable
              onPress={google}
              disabled={busy}
              accessibilityRole="button"
              style={{ height: 54, borderRadius: 20, borderWidth: 1, borderColor: '#2A2535', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, opacity: busy ? 0.6 : 1 }}
            >
              <Ionicons name="logo-google" size={22} color="#FFFFFF" />
              <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '700' }}>Continuar com Google</Text>
            </Pressable>

            <Text style={{ textAlign: 'center', fontSize: 12, fontWeight: '500', color: '#D9B27C' }}>
              Dados sincronizados na nuvem · Funciona no Android e no iPhone
            </Text>
          </View>
        </LinearGradient>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
