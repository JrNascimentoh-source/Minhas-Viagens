import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, Text, View } from 'react-native';
import { Button, Label, Screen } from '../../src/components/ui';
import { PERIOD_LABEL, brl, formatBR, formatTime } from '../../src/lib/dates';
import { cancelReminder, scheduleReminder } from '../../src/lib/notifications';
import { confirmTrip, getTrip } from '../../src/lib/trips';
import { Trip } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';

export default function ConfirmTrip() {
  const { colors } = useTheme();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [loading, setLoading] = useState(true);
  const [completed, setCompleted] = useState<boolean | null>(null);
  const [paid, setPaid] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getTrip(String(id))
      .then(setTrip)
      .catch((e) => Alert.alert('Erro', e?.message ?? 'Não foi possível carregar a viagem.'))
      .finally(() => setLoading(false));
  }, [id]);

  const choice = (label: string, active: boolean, onPress: () => void) => (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      style={{
        flex: 1,
        height: 50,
        borderRadius: 15,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: active ? colors.accent : colors.card,
        borderWidth: active ? 0 : 1,
        borderColor: colors.line,
      }}
    >
      <Text style={{ fontSize: 15, fontWeight: '700', color: active ? colors.onAccent : colors.ink }}>{label}</Text>
    </Pressable>
  );

  const submit = async () => {
    if (!trip) return;
    if (completed === null) return Alert.alert('Falta responder', 'A viagem foi concluída?');
    if (completed && paid === null) return Alert.alert('Falta responder', 'O pagamento já foi feito?');
    setBusy(true);
    try {
      const updated = await confirmTrip(trip.id, { completed, paid: paid ?? false });
      if (completed) await cancelReminder(trip.id);
      else await scheduleReminder(updated);
      router.back();
    } catch (e: any) {
      Alert.alert('Não foi possível salvar', e?.message ?? 'Tente novamente.');
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
        <ActivityIndicator color={colors.accent} />
      </View>
    );
  }

  if (!trip || trip.status === 'registered') {
    return (
      <Screen tabs={false}>
        <Text style={{ fontSize: 22, fontWeight: '800', color: colors.ink }}>
          {trip ? 'Esta viagem já foi registrada.' : 'Viagem não encontrada.'}
        </Text>
        <Button label="Fechar" onPress={() => router.back()} />
      </Screen>
    );
  }

  return (
    <Screen tabs={false}>
      <View>
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.ink }}>Confirmar viagem</Text>
        <Text style={{ fontSize: 14, fontWeight: '500', color: colors.muted, marginTop: 2 }}>
          {formatBR(trip.trip_date)} · saiu às {formatTime(trip.departed_at)} · {PERIOD_LABEL[trip.period]} · {brl(Number(trip.amount))}
        </Text>
        {trip.description ? <Text style={{ fontSize: 14, color: colors.muted }}>{trip.description}</Text> : null}
      </View>

      <View style={{ gap: 8 }}>
        <Label>A viagem foi concluída?</Label>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {choice('Sim, concluída', completed === true, () => setCompleted(true))}
          {choice('Ainda não', completed === false, () => setCompleted(false))}
        </View>
      </View>

      {completed === true ? (
        <View style={{ gap: 8 }}>
          <Label>O pagamento já foi feito?</Label>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {choice('Sim, pago', paid === true, () => setPaid(true))}
            {choice('Ainda não', paid === false, () => setPaid(false))}
          </View>
        </View>
      ) : null}

      <Text style={{ fontSize: 13, color: colors.muted }}>
        Só depois da confirmação a viagem vai para o registro. Se faltar algo, avisamos de novo em 9 horas.
      </Text>

      <Button label={busy ? 'Salvando…' : 'Confirmar e registrar'} onPress={submit} disabled={busy} style={{ height: 56 }} />
      <Button label="Fechar" variant="outline" onPress={() => router.back()} />
    </Screen>
  );
}
