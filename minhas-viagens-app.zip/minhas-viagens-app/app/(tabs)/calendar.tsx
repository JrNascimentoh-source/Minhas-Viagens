import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Card, MonthSwitcher, Screen, Title, TripRow } from '../../src/components/ui';
import { daysInMonth, formatBR, toISODate } from '../../src/lib/dates';
import { cancelReminder } from '../../src/lib/notifications';
import { DayStatus, dayStatus, deleteTrip, groupByDate, listTripsByMonth, markPaid } from '../../src/lib/trips';
import { Trip } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';

const WEEK = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

export default function CalendarScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month0, setMonth0] = useState(today.getMonth());
  const [trips, setTrips] = useState<Trip[]>([]);
  const [selected, setSelected] = useState<string | null>(toISODate(today));

  const load = useCallback(async () => {
    try {
      setTrips(await listTripsByMonth(year, month0));
    } catch (e: any) {
      Alert.alert('Não foi possível carregar', e?.message ?? 'Verifique sua conexão.');
    }
  }, [year, month0]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const byDate = useMemo(() => groupByDate(trips), [trips]);
  const todayISO = toISODate(today);
  const blanks = new Date(year, month0, 1).getDay();
  const total = daysInMonth(year, month0);

  const cellStyle = (s: DayStatus) => {
    switch (s) {
      case 'worked':
        return { bg: colors.accent, fg: colors.onAccent, border: colors.accent, dashed: false };
      case 'open':
        return { bg: 'transparent', fg: colors.accent, border: colors.accent, dashed: true };
      case 'none':
        return { bg: colors.track, fg: colors.muted, border: colors.line, dashed: false };
      case 'today':
        return { bg: 'transparent', fg: colors.ink, border: colors.ink, dashed: false };
      default:
        return { bg: 'transparent', fg: colors.muted, border: 'transparent', dashed: false };
    }
  };

  const onTripPress = (trip: Trip) => {
    const buttons: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [];
    if (trip.status === 'open') buttons.push({ text: 'Confirmar viagem', onPress: () => router.push(`/confirm/${trip.id}`) });
    if (trip.status === 'registered' && !trip.paid) {
      buttons.push({
        text: 'Marcar como pago',
        onPress: async () => {
          await markPaid(trip.id);
          load();
        },
      });
    }
    buttons.push({
      text: 'Excluir',
      style: 'destructive',
      onPress: async () => {
        await cancelReminder(trip.id);
        await deleteTrip(trip.id);
        load();
      },
    });
    buttons.push({ text: 'Fechar', style: 'cancel' });
    Alert.alert(formatBR(trip.trip_date), trip.description || 'Viagem', buttons);
  };

  const cells: React.ReactNode[] = [];
  for (let i = 0; i < blanks; i++) cells.push(<View key={`b${i}`} style={{ width: '14.2857%' }} />);
  for (let d = 1; d <= total; d++) {
    const iso = toISODate(new Date(year, month0, d));
    const s = dayStatus(iso, byDate, todayISO);
    const c = cellStyle(s);
    const isSel = selected === iso;
    cells.push(
      <View key={iso} style={{ width: '14.2857%', padding: 3 }}>
        <Pressable
          onPress={() => setSelected(iso)}
          accessibilityRole="button"
          accessibilityLabel={`Dia ${d}`}
          style={{
            height: 44,
            borderRadius: 22,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: c.bg,
            borderWidth: isSel ? 3 : c.dashed ? 2 : 1,
            borderStyle: c.dashed && !isSel ? 'dashed' : 'solid',
            borderColor: isSel ? colors.ink : c.border,
          }}
        >
          <Text style={{ fontSize: 14, fontWeight: '700', color: c.fg }}>{d}</Text>
        </Pressable>
      </View>
    );
  }

  const legend = (label: string, bg: string, border: string, dashed = false) => (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, width: '48%' }}>
      <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: bg, borderColor: border, borderWidth: dashed ? 2 : 1, borderStyle: dashed ? 'dashed' : 'solid' }} />
      <Text style={{ fontSize: 13, fontWeight: '600', color: colors.ink }}>{label}</Text>
    </View>
  );

  const dayTrips = selected ? byDate[selected] ?? [] : [];

  return (
    <Screen>
      <Title>Calendário</Title>
      <MonthSwitcher
        year={year}
        month0={month0}
        onChange={(y, m) => {
          setYear(y);
          setMonth0(m);
          setSelected(null);
        }}
      />
      <Card style={{ paddingHorizontal: 10 }}>
        <View style={{ flexDirection: 'row', marginBottom: 6 }}>
          {WEEK.map((w, i) => (
            <Text key={i} style={{ width: '14.2857%', textAlign: 'center', fontSize: 12, fontWeight: '700', color: colors.muted }}>
              {w}
            </Text>
          ))}
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{cells}</View>
      </Card>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'space-between' }}>
        {legend('Trabalhado', colors.accent, colors.accent)}
        {legend('Sem viagem', colors.track, colors.line)}
        {legend('Em aberto', 'transparent', colors.accent, true)}
        {legend('Dias futuros', 'transparent', colors.line)}
      </View>

      {selected ? (
        <View style={{ gap: 8 }}>
          <Text style={{ fontSize: 15, fontWeight: '800', color: colors.ink }}>{formatBR(selected)}</Text>
          {dayTrips.length === 0 ? (
            <Text style={{ fontSize: 14, color: colors.muted }}>Nenhuma viagem neste dia.</Text>
          ) : (
            dayTrips.map((t) => <TripRow key={t.id} trip={t} onPress={() => onTripPress(t)} />)
          )}
        </View>
      ) : null}
    </Screen>
  );
}
