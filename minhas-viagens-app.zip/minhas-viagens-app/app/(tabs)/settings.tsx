import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, Switch, Text, View } from 'react-native';
import { useAuth } from '../../src/auth/AuthProvider';
import { Button, Card, Label, Screen, Title } from '../../src/components/ui';
import { remindersEnabled, setRemindersEnabled, setupNotifications, syncReminders } from '../../src/lib/notifications';
import { REMINDER_HOURS, listOpenTrips } from '../../src/lib/trips';
import { ThemeMode, useTheme } from '../../src/theme/ThemeProvider';

const OPTIONS: { mode: ThemeMode; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { mode: 'light', label: 'Claro', icon: 'sunny-outline' },
  { mode: 'dark', label: 'Escuro', icon: 'moon-outline' },
  { mode: 'auto', label: 'Automático', icon: 'contrast-outline' },
];

export default function Settings() {
  const { colors, mode, setMode } = useTheme();
  const { session, signOut } = useAuth();
  const [reminders, setReminders] = useState(true);

  useEffect(() => {
    remindersEnabled().then(setReminders);
  }, []);

  const toggleReminders = async (value: boolean) => {
    setReminders(value);
    await setRemindersEnabled(value);
    if (value) {
      const ok = await setupNotifications();
      if (!ok) Alert.alert('Permissão necessária', 'Ative as notificações do app nas configurações do celular.');
      await syncReminders(await listOpenTrips());
    }
  };

  return (
    <Screen>
      <Title>Ajustes</Title>

      <View style={{ gap: 10 }}>
        <Label>Tema</Label>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {OPTIONS.map((o) => {
            const on = mode === o.mode;
            return (
              <Pressable
                key={o.mode}
                onPress={() => setMode(o.mode)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={{
                  flex: 1,
                  height: 104,
                  borderRadius: 20,
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 10,
                  borderWidth: on ? 2 : 1,
                  borderColor: on ? colors.accent : colors.line,
                  backgroundColor: on ? colors.accentSoft : colors.card,
                }}
              >
                <Ionicons name={o.icon} size={28} color={on ? colors.accent : colors.ink} />
                <Text style={{ fontSize: 14, fontWeight: on ? '800' : '700', color: on ? colors.accent : colors.ink }}>{o.label}</Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={{ fontSize: 13, color: colors.muted }}>Automático acompanha o tema claro ou escuro do seu celular.</Text>
      </View>

      <View style={{ gap: 10 }}>
        <Label>Lembretes</Label>
        <Card style={{ padding: 0 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, minHeight: 64 }}>
            <View style={{ flex: 1, paddingRight: 12 }}>
              <Text style={{ fontSize: 15, fontWeight: '700', color: colors.ink }}>Confirmar viagens abertas</Text>
              <Text style={{ fontSize: 13, color: colors.muted }}>Notificação a cada {REMINDER_HOURS} horas</Text>
            </View>
            <Switch value={reminders} onValueChange={toggleReminders} trackColor={{ true: colors.accent }} />
          </View>
        </Card>
      </View>

      <View style={{ gap: 10 }}>
        <Label>Conta</Label>
        <Card style={{ gap: 12 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.ink }}>{session?.user.email}</Text>
          <Button label="Sair" variant="outline" icon="log-out-outline" onPress={signOut} />
        </Card>
      </View>
    </Screen>
  );
}
