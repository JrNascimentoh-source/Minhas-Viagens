import { Ionicons } from '@expo/vector-icons';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Path, Stop } from 'react-native-svg';

const ACTIVE = '#FF9A3D';
const INACTIVE = '#CFCAE6';
const BAR_W = 358;
const BAR_H = 92;

const TABS: Record<string, { label: string; icon: keyof typeof Ionicons.glyphMap; iconOn: keyof typeof Ionicons.glyphMap }> = {
  index: { label: 'Início', icon: 'home-outline', iconOn: 'home' },
  calendar: { label: 'Calendário', icon: 'calendar-outline', iconOn: 'calendar' },
  report: { label: 'Relatório', icon: 'document-text-outline', iconOn: 'document-text' },
  settings: { label: 'Ajustes', icon: 'options-outline', iconOn: 'options' },
};

export function TabBar({ state, navigation }: BottomTabBarProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const barW = Math.min(BAR_W, width - 24);
  const s = barW / BAR_W;

  const renderTab = (routeName: string) => {
    const idx = state.routes.findIndex((r) => r.name === routeName);
    if (idx < 0) return null;
    const route = state.routes[idx];
    const focused = state.index === idx;
    const cfg = TABS[routeName];
    const onPress = () => {
      const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
      if (!focused && !event.defaultPrevented) navigation.navigate(route.name, route.params);
    };
    return (
      <Pressable
        key={route.key}
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={cfg.label}
        accessibilityState={{ selected: focused }}
        style={{ width: 62 * s, height: 56, alignItems: 'center', justifyContent: 'center', gap: 3 }}
      >
        <Ionicons name={focused ? cfg.iconOn : cfg.icon} size={22} color={focused ? ACTIVE : INACTIVE} />
        <Text style={{ fontSize: 11, fontWeight: focused ? '800' : '600', color: focused ? ACTIVE : INACTIVE }}>
          {cfg.label}
        </Text>
        <View style={{ width: 18, height: 3, borderRadius: 2, backgroundColor: focused ? ACTIVE : 'transparent' }} />
      </Pressable>
    );
  };

  return (
    <View
      style={{
        position: 'absolute',
        alignSelf: 'center',
        bottom: Math.max(insets.bottom, 12),
        width: barW,
        height: BAR_H * s,
      }}
      pointerEvents="box-none"
    >
      <Svg width={barW} height={BAR_H * s} viewBox={`0 0 ${BAR_W} ${BAR_H}`} style={{ position: 'absolute' }}>
        <Defs>
          <LinearGradient id="navgrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2={String(BAR_W)} y2="0">
            <Stop offset="0" stopColor="#FF9A3D" />
            <Stop offset="0.5" stopColor="#A64DFF" />
            <Stop offset="1" stopColor="#3D8BFF" />
          </LinearGradient>
        </Defs>
        <Path
          d="M30 20 H106 C120 20 122 4 138 4 H220 C236 4 238 20 252 20 H328 A28 28 0 0 1 356 48 V62 A28 28 0 0 1 328 90 H30 A28 28 0 0 1 2 62 V48 A28 28 0 0 1 30 20 Z"
          fill="#15121F"
          stroke="url(#navgrad)"
          strokeWidth={2.5}
          strokeLinejoin="round"
        />
      </Svg>

      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 20 * s,
          height: 70 * s,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingHorizontal: 12 * s,
        }}
      >
        {renderTab('index')}
        {renderTab('calendar')}
        <View style={{ width: 64 * s }} />
        {renderTab('report')}
        {renderTab('settings')}
      </View>

      <Pressable
        onPress={() => router.push('/new-trip')}
        accessibilityRole="button"
        accessibilityLabel="Nova viagem"
        style={{
          position: 'absolute',
          left: barW / 2 - 26,
          top: 9 * s,
          width: 52,
          height: 52,
          borderRadius: 16,
          borderWidth: 2.5,
          borderColor: '#4C94FF',
          backgroundColor: '#1B1640',
          alignItems: 'center',
          justifyContent: 'center',
          shadowColor: '#4C94FF',
          shadowOpacity: 0.6,
          shadowRadius: 10,
          shadowOffset: { width: 0, height: 0 },
          elevation: 8,
        }}
      >
        <Ionicons name="add" size={30} color="#FFFFFF" />
      </Pressable>
    </View>
  );
}

/** Espaço que as telas precisam deixar no final para não ficar atrás da barra. */
export const TAB_BAR_SPACE = 130;
