import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';

export type ThemeMode = 'light' | 'dark' | 'auto';

export type Colors = {
  bg: string;
  card: string;
  ink: string;
  muted: string;
  line: string;
  accent: string;
  onAccent: string;
  accentSoft: string;
  ok: string;
  okSoft: string;
  track: string;
};

const light: Colors = {
  bg: '#F6F4F1',
  card: '#FFFFFF',
  ink: '#1B1A19',
  muted: '#66625D',
  line: '#E7E3DE',
  accent: '#D9480F',
  onAccent: '#FFFFFF',
  accentSoft: '#FDEBDD',
  ok: '#0B7A6B',
  okSoft: '#DDF3EF',
  track: '#ECE8E3',
};

const dark: Colors = {
  bg: '#111113',
  card: '#1C1C1F',
  ink: '#F3F1EE',
  muted: '#A9A49E',
  line: '#2B2B2F',
  accent: '#FF8A3D',
  onAccent: '#1A1209',
  accentSoft: '#3A2517',
  ok: '#4FD1BC',
  okSoft: '#14332F',
  track: '#2C2C30',
};

type ThemeCtx = { mode: ThemeMode; setMode: (m: ThemeMode) => void; isDark: boolean; colors: Colors };

const Ctx = createContext<ThemeCtx>({ mode: 'auto', setMode: () => {}, isDark: false, colors: light });
const KEY = 'theme_mode';

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('auto');

  useEffect(() => {
    AsyncStorage.getItem(KEY).then((v) => {
      if (v === 'light' || v === 'dark' || v === 'auto') setModeState(v);
    });
  }, []);

  const setMode = (m: ThemeMode) => {
    setModeState(m);
    AsyncStorage.setItem(KEY, m);
  };

  const value = useMemo(() => {
    const isDark = mode === 'auto' ? system === 'dark' : mode === 'dark';
    return { mode, setMode, isDark, colors: isDark ? dark : light };
  }, [mode, system]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useTheme = () => useContext(Ctx);
