import { Alert, Platform } from 'react-native';

export type AlertButton = { text: string; style?: 'default' | 'cancel' | 'destructive'; onPress?: () => void };
export type AlertPayload = { title: string; message?: string; buttons: AlertButton[] };

let listener: ((p: AlertPayload | null) => void) | null = null;

/** Usado pelo WebAlertHost: no navegador, Alert.alert do React Native não aparece. */
export function setWebAlertListener(l: ((p: AlertPayload | null) => void) | null) {
  listener = l;
}

export function showAlert(title: string, message?: string, buttons?: AlertButton[]) {
  const list = buttons && buttons.length ? buttons : [{ text: 'OK' }];
  if (Platform.OS === 'web' && listener) {
    listener({ title, message, buttons: list });
    return;
  }
  Alert.alert(title, message, list);
}
