import React, { useEffect, useState } from 'react';
import { Modal, Platform, Pressable, Text, View } from 'react-native';
import { AlertPayload, setWebAlertListener } from '../lib/alert';
import { useTheme } from '../theme/ThemeProvider';

/** Caixa de diálogo usada no navegador no lugar do Alert nativo. */
export function WebAlertHost() {
  const { colors } = useTheme();
  const [payload, setPayload] = useState<AlertPayload | null>(null);

  useEffect(() => {
    if (Platform.OS !== 'web') return;
    setWebAlertListener(setPayload);
    return () => setWebAlertListener(null);
  }, []);

  if (!payload) return null;
  const close = () => setPayload(null);

  return (
    <Modal transparent animationType="fade" visible onRequestClose={close}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <View style={{ width: '100%', maxWidth: 380, backgroundColor: colors.card, borderRadius: 24, padding: 20, gap: 14, borderWidth: 1, borderColor: colors.line }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: colors.ink }}>{payload.title}</Text>
          {payload.message ? <Text style={{ fontSize: 14, color: colors.muted }}>{payload.message}</Text> : null}
          <View style={{ gap: 8 }}>
            {payload.buttons.map((b, i) => {
              const destructive = b.style === 'destructive';
              const cancel = b.style === 'cancel';
              return (
                <Pressable
                  key={i}
                  accessibilityRole="button"
                  onPress={() => {
                    close();
                    b.onPress?.();
                  }}
                  style={{
                    height: 48,
                    borderRadius: 14,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: cancel || destructive ? 'transparent' : colors.accent,
                    borderWidth: cancel || destructive ? 1.5 : 0,
                    borderColor: destructive ? '#D92D20' : colors.line,
                  }}
                >
                  <Text style={{ fontSize: 15, fontWeight: '800', color: destructive ? '#D92D20' : cancel ? colors.ink : colors.onAccent }}>
                    {b.text}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>
      </View>
    </Modal>
  );
}
