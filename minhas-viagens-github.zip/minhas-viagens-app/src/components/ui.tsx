import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, ScrollView, StyleProp, Text, View, ViewStyle, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MONTHS, PERIOD_LABEL, brl, formatBR } from '../lib/dates';
import { Trip } from '../lib/types';
import { useTheme } from '../theme/ThemeProvider';
import { TAB_BAR_SPACE } from './TabBar';

export function Screen({
  children,
  tabs = true,
  refreshing,
  onRefresh,
}: {
  children: React.ReactNode;
  tabs?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
}) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{
        paddingTop: insets.top + 16,
        paddingHorizontal: 20,
        paddingBottom: tabs ? TAB_BAR_SPACE + insets.bottom : insets.bottom + 24,
        gap: 16,
      }}
      keyboardShouldPersistTaps="handled"
      refreshControl={
        onRefresh ? (
          <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={colors.accent} />
        ) : undefined
      }
    >
      {children}
    </ScrollView>
  );
}

export function Title({ children, sub }: { children: React.ReactNode; sub?: string }) {
  const { colors } = useTheme();
  return (
    <View>
      {sub ? <Text style={{ fontSize: 13, fontWeight: '600', color: colors.muted }}>{sub}</Text> : null}
      <Text style={{ fontSize: 26, fontWeight: '800', color: colors.ink, letterSpacing: -0.4 }}>{children}</Text>
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  return (
    <View
      style={[
        { backgroundColor: colors.card, borderColor: colors.line, borderWidth: 1, borderRadius: 24, padding: 18 },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function Button({
  label,
  onPress,
  variant = 'primary',
  disabled,
  icon,
  style,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'outline';
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  style?: StyleProp<ViewStyle>;
}) {
  const { colors } = useTheme();
  const primary = variant === 'primary';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      style={[
        {
          height: 52,
          borderRadius: 16,
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          gap: 8,
          opacity: disabled ? 0.5 : 1,
          backgroundColor: primary ? colors.accent : 'transparent',
          borderWidth: primary ? 0 : 1.5,
          borderColor: colors.accent,
        },
        style,
      ]}
    >
      {icon ? <Ionicons name={icon} size={20} color={primary ? colors.onAccent : colors.accent} /> : null}
      <Text style={{ fontSize: 15, fontWeight: '800', color: primary ? colors.onAccent : colors.accent }}>{label}</Text>
    </Pressable>
  );
}

export function MonthSwitcher({
  year,
  month0,
  onChange,
}: {
  year: number;
  month0: number;
  onChange: (year: number, month0: number) => void;
}) {
  const { colors } = useTheme();
  const shift = (delta: number) => {
    const d = new Date(year, month0 + delta, 1);
    onChange(d.getFullYear(), d.getMonth());
  };
  const arrow = (dir: -1 | 1) => (
    <Pressable
      onPress={() => shift(dir)}
      accessibilityRole="button"
      accessibilityLabel={dir < 0 ? 'Mês anterior' : 'Próximo mês'}
      style={{
        width: 44,
        height: 44,
        borderRadius: 22,
        borderWidth: 1,
        borderColor: colors.line,
        backgroundColor: colors.card,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Ionicons name={dir < 0 ? 'chevron-back' : 'chevron-forward'} size={18} color={colors.ink} />
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
      {arrow(-1)}
      <Text style={{ fontSize: 16, fontWeight: '800', color: colors.ink }}>
        {MONTHS[month0]} {year}
      </Text>
      {arrow(1)}
    </View>
  );
}

export function TripRow({ trip, onPress }: { trip: Trip; onPress?: () => void }) {
  const { colors } = useTheme();
  const status =
    trip.status === 'open'
      ? { text: 'Em aberto', color: colors.accent }
      : trip.paid
        ? { text: 'Pago', color: colors.ok }
        : { text: 'A receber', color: colors.muted };
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={{
        backgroundColor: colors.card,
        borderColor: colors.line,
        borderWidth: 1,
        borderRadius: 18,
        paddingVertical: 12,
        paddingHorizontal: 14,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '700', color: colors.ink }}>
          {formatBR(trip.trip_date).slice(0, 5)} · {PERIOD_LABEL[trip.period]}
        </Text>
        <Text numberOfLines={1} style={{ fontSize: 13, fontWeight: '500', color: colors.muted }}>
          {trip.description || 'Sem descrição'}
        </Text>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={{ fontSize: 15, fontWeight: '800', color: colors.ink }}>{brl(Number(trip.amount))}</Text>
        <Text style={{ fontSize: 12, fontWeight: '700', color: status.color }}>{status.text}</Text>
      </View>
    </Pressable>
  );
}

export function Label({ children }: { children: React.ReactNode }) {
  const { colors } = useTheme();
  return <Text style={{ fontSize: 13, fontWeight: '700', color: colors.muted }}>{children}</Text>;
}
