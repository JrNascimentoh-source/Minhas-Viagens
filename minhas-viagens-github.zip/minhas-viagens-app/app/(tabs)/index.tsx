import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { showAlert } from '../../src/lib/alert';
import { Text, View } from 'react-native';
import { DonutChart } from '../../src/components/DonutChart';
import { Button, Card, Screen, Title, TripRow } from '../../src/components/ui';
import { MONTHS, PERIOD_LABEL, brl, formatBR, formatTime } from '../../src/lib/dates';
import { NOTIFICATIONS_SUPPORTED, scheduleReminder, syncReminders } from '../../src/lib/notifications';
import { listOpenTrips, listTripsByMonth, monthStats, snoozeTrip } from '../../src/lib/trips';
import { Trip } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';

export default function Home() {
  const { colors } = useTheme();
  const router = useRouter();
  const now = new Date();
  const year = now.getFullYear();
  const month0 = now.getMonth();

  const [monthTrips, setMonthTrips] = useState<Trip[]>([]);
  const [open, setOpen] = useState<Trip[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [m, o] = await Promise.all([listTripsByMonth(year, month0), listOpenTrips()]);
      setMonthTrips(m);
      setOpen(o);
      await syncReminders(o);
    } catch (e: any) {
      showAlert('Não foi possível carregar', e?.message ?? 'Verifique sua conexão.');
    }
  }, [year, month0]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const refresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const notYet = async (trip: Trip) => {
    try {
      await snoozeTrip(trip.id);
      await scheduleReminder(trip);
      showAlert('Combinado', NOTIFICATIONS_SUPPORTED ? 'Vamos lembrar de novo em 9 horas.' : 'A viagem continua em aberto.');
      load();
    } catch (e: any) {
      showAlert('Erro', e?.message ?? 'Tente novamente.');
    }
  };

  const stats = monthStats(monthTrips, year, month0);
  const recent = monthTrips.filter((t) => t.status === 'registered').slice(0, 5);

  return (
    <Screen refreshing={refreshing} onRefresh={refresh}>
      <Title sub={`${MONTHS[month0]} ${year}`}>Minhas viagens</Title>

      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 18 }}>
        <DonutChart percent={stats.percentWorked} color={colors.accent} track={colors.track} label={`${stats.percentWorked}% dos dias trabalhados`}>
          <Text style={{ fontSize: 28, fontWeight: '800', color: colors.ink }}>{stats.percentWorked}%</Text>
          <Text style={{ fontSize: 11, fontWeight: '600', color: colors.muted }}>trabalhados</Text>
        </DonutChart>
        <View style={{ flex: 1, gap: 12 }}>
          <View>
            <Text style={{ fontSize: 12, fontWeight: '600', color: colors.muted }}>Recebido no mês</Text>
            <Text style={{ fontSize: 24, fontWeight: '800', color: colors.ink }}>{brl(stats.totalReceived)}</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 18 }}>
            <View>
              <Text style={{ fontSize: 20, fontWeight: '800', color: colors.accent }}>{stats.workedDays}</Text>
              <Text style={{ fontSize: 12, fontWeight: '600', color: colors.muted }}>dias com viagem</Text>
            </View>
            <View>
              <Text style={{ fontSize: 20, fontWeight: '800', color: colors.ink }}>{stats.notWorkedDays}</Text>
              <Text style={{ fontSize: 12, fontWeight: '600', color: colors.muted }}>sem viagem</Text>
            </View>
          </View>
        </View>
      </Card>

      {open.map((trip) => (
        <View
          key={trip.id}
          style={{ backgroundColor: colors.accentSoft, borderColor: colors.accent, borderWidth: 1, borderRadius: 22, padding: 16, gap: 12 }}
        >
          <Text style={{ fontSize: 12, fontWeight: '800', color: colors.accent, letterSpacing: 0.5 }}>AGUARDANDO CONFIRMAÇÃO</Text>
          <View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: colors.ink }}>
              {formatBR(trip.trip_date)} · saiu às {formatTime(trip.departed_at)} · {PERIOD_LABEL[trip.period]}
            </Text>
            <Text style={{ fontSize: 14, fontWeight: '500', color: colors.muted, marginTop: 2 }}>
              {trip.description || 'Sem descrição'} · {brl(Number(trip.amount))}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button label="Concluída" onPress={() => router.push(`/confirm/${trip.id}`)} style={{ flex: 1, height: 46 }} />
            <Button label="Ainda não" variant="outline" onPress={() => notYet(trip)} style={{ flex: 1, height: 46 }} />
          </View>
        </View>
      ))}

      <View style={{ gap: 8 }}>
        <Text style={{ fontSize: 15, fontWeight: '800', color: colors.ink }}>Registradas recentemente</Text>
        {recent.length === 0 ? (
          <Text style={{ fontSize: 14, color: colors.muted }}>Nenhuma viagem registrada ainda neste mês. Toque no + para adicionar.</Text>
        ) : (
          recent.map((t) => <TripRow key={t.id} trip={t} />)
        )}
      </View>
    </Screen>
  );
}
