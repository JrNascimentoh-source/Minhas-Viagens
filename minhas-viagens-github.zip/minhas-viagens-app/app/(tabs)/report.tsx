import { useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { showAlert } from '../../src/lib/alert';
import { Text, View } from 'react-native';
import { DonutChart } from '../../src/components/DonutChart';
import { Button, Card, MonthSwitcher, Screen, Title } from '../../src/components/ui';
import { MONTHS, brl } from '../../src/lib/dates';
import { generateReportPdf } from '../../src/lib/report';
import { listTripsByMonth, monthStats } from '../../src/lib/trips';
import { Trip } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';

export default function ReportScreen() {
  const { colors } = useTheme();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month0, setMonth0] = useState(now.getMonth());
  const [trips, setTrips] = useState<Trip[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setTrips(await listTripsByMonth(year, month0));
    } catch (e: any) {
      showAlert('Não foi possível carregar', e?.message ?? 'Verifique sua conexão.');
    }
  }, [year, month0]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const stats = monthStats(trips, year, month0);

  const generate = async () => {
    setBusy(true);
    try {
      await generateReportPdf(year, month0, stats, trips);
    } catch (e: any) {
      showAlert('Não foi possível gerar o PDF', e?.message ?? 'Tente novamente.');
    } finally {
      setBusy(false);
    }
  };

  const row = (label: string, value: string, color?: string, last = false) => (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        paddingVertical: 11,
        borderTopWidth: 1,
        borderBottomWidth: last ? 1 : 0,
        borderColor: colors.line,
      }}
    >
      <Text style={{ fontSize: 14, fontWeight: '600', color: colors.muted }}>{label}</Text>
      <Text style={{ fontSize: 20, fontWeight: '800', color: color ?? colors.ink }}>{value}</Text>
    </View>
  );

  return (
    <Screen>
      <Title>Relatório</Title>
      <MonthSwitcher
        year={year}
        month0={month0}
        onChange={(y, m) => {
          setYear(y);
          setMonth0(m);
        }}
      />

      <Card style={{ borderRadius: 16, padding: 20, gap: 14 }}>
        <View>
          <Text style={{ fontSize: 11, fontWeight: '800', color: colors.accent, letterSpacing: 1 }}>RELATÓRIO MENSAL</Text>
          <Text style={{ fontSize: 20, fontWeight: '800', color: colors.ink }}>
            {MONTHS[month0]} de {year}
          </Text>
        </View>
        <View>
          {row('Dias trabalhados', String(stats.workedDays))}
          {row('Dias não trabalhados', String(stats.notWorkedDays))}
          {row('Total recebido', brl(stats.totalReceived), colors.accent, true)}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <DonutChart percent={stats.percentWorked} size={72} stroke={9} color={colors.accent} track={colors.track} label={`${stats.percentWorked}% dos dias trabalhados`} />
          <View style={{ gap: 6 }}>
            <Text style={{ fontSize: 13, fontWeight: '600', color: colors.ink }}>Trabalhados · {stats.percentWorked}%</Text>
            <Text style={{ fontSize: 13, fontWeight: '600', color: colors.ink }}>Sem viagem · {stats.percentWorked === 0 && stats.workedDays + stats.notWorkedDays === 0 ? 0 : 100 - stats.percentWorked}%</Text>
          </View>
        </View>
        <Text style={{ fontSize: 12, fontWeight: '500', color: colors.muted }}>
          Considera apenas viagens confirmadas como concluídas e pagas.
        </Text>
      </Card>

      <Button label={busy ? 'Gerando…' : 'Gerar relatório em PDF'} icon="download-outline" onPress={generate} disabled={busy} />
    </Screen>
  );
}
