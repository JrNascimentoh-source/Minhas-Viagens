import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { showAlert } from '../src/lib/alert';
import { KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { Button, Label, Screen } from '../src/components/ui';
import { PERIOD_LABEL, formatBR, maskDate, parseBR, parseMoney, periodOf, toISODate } from '../src/lib/dates';
import { scheduleReminder } from '../src/lib/notifications';
import { createTrip } from '../src/lib/trips';
import { useTheme } from '../src/theme/ThemeProvider';

export default function NewTrip() {
  const { colors } = useTheme();
  const router = useRouter();
  const now = new Date();
  const [date, setDate] = useState(formatBR(toISODate(now)));
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);

  const setDay = (offset: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    setDate(formatBR(toISODate(d)));
  };

  const save = async () => {
    const iso = parseBR(date);
    const value = parseMoney(amount);
    if (!iso) return showAlert('Data inválida', 'Use o formato DD/MM/AAAA.');
    if (value === null) return showAlert('Valor inválido', 'Informe o valor da viagem, por exemplo 160,00.');
    setBusy(true);
    try {
      const trip = await createTrip({ tripDate: iso, amount: value, description: description.trim() });
      await scheduleReminder(trip);
      router.back();
    } catch (e: any) {
      showAlert('Não foi possível salvar', e?.message ?? 'Tente novamente.');
    } finally {
      setBusy(false);
    }
  };

  const inputStyle = {
    height: 54,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.card,
    color: colors.ink,
    paddingHorizontal: 16,
    fontSize: 16,
    fontWeight: '600' as const,
  };

  const chip = (label: string, offset: number) => (
    <Pressable
      onPress={() => setDay(offset)}
      accessibilityRole="button"
      style={{ height: 40, paddingHorizontal: 16, borderRadius: 20, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.card, justifyContent: 'center' }}
    >
      <Text style={{ fontSize: 13, fontWeight: '700', color: colors.ink }}>{label}</Text>
    </Pressable>
  );

  const info = (label: string, value: string) => (
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: 12, fontWeight: '600', color: colors.muted }}>{label}</Text>
      <Text style={{ fontSize: 17, fontWeight: '800', color: colors.ink }}>{value}</Text>
    </View>
  );

  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen tabs={false}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={{ fontSize: 26, fontWeight: '800', color: colors.ink }}>Nova viagem</Text>
          <Pressable
            onPress={() => router.back()}
            accessibilityRole="button"
            accessibilityLabel="Fechar"
            style={{ width: 46, height: 46, borderRadius: 23, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' }}
          >
            <Ionicons name="close" size={22} color={colors.ink} />
          </Pressable>
        </View>

        <View style={{ gap: 8 }}>
          <Label>Dia da viagem</Label>
          <TextInput value={date} onChangeText={(t) => setDate(maskDate(t))} keyboardType="number-pad" placeholder="DD/MM/AAAA" placeholderTextColor={colors.muted} style={inputStyle} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {chip('Hoje', 0)}
            {chip('Ontem', -1)}
          </View>
        </View>

        <View style={{ gap: 8 }}>
          <Label>Valor</Label>
          <TextInput value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="R$ 0,00" placeholderTextColor={colors.muted} style={inputStyle} />
        </View>

        <View style={{ gap: 8 }}>
          <Label>Descrição</Label>
          <TextInput value={description} onChangeText={setDescription} placeholder="Ex.: Corrida aeroporto" placeholderTextColor={colors.muted} style={inputStyle} />
        </View>

        <View style={{ backgroundColor: colors.accentSoft, borderColor: colors.accent, borderWidth: 1, borderRadius: 20, padding: 16, gap: 10 }}>
          <Text style={{ fontSize: 12, fontWeight: '800', color: colors.accent, letterSpacing: 0.5 }}>REGISTRADO AUTOMATICAMENTE AO SALVAR</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {info('Saída', `${hh}:${mm}`)}
            {info('Data', formatBR(toISODate(now)).slice(0, 5))}
            {info('Período', PERIOD_LABEL[periodOf(now)])}
          </View>
          <Text style={{ fontSize: 13, color: colors.muted }}>
            A viagem fica em aberto e o app avisa a cada 9 horas até você confirmar conclusão e pagamento.
          </Text>
        </View>

        <Button label={busy ? 'Salvando…' : 'Salvar viagem'} onPress={save} disabled={busy} style={{ height: 56 }} />
      </Screen>
    </KeyboardAvoidingView>
  );
}
