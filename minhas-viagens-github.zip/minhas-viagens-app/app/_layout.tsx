import * as Notifications from 'expo-notifications';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { Platform, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from '../src/auth/AuthProvider';
import { WebAlertHost } from '../src/components/WebAlertHost';
import { NOTIFICATIONS_SUPPORTED, setupNotifications } from '../src/lib/notifications';
import { ThemeProvider, useTheme } from '../src/theme/ThemeProvider';

const handledNotifications = new Set<string>();

function Gate() {
  const { session, loading } = useAuth();
  const { isDark, colors } = useTheme();
  const segments = useSegments();
  const router = useRouter();
  const inLogin = segments[0] === 'login';

  // Redireciona conforme o estado de login
  useEffect(() => {
    if (loading) return;
    if (!session && !inLogin) router.replace('/login');
    else if (session && inLogin) router.replace('/');
  }, [session, loading, inLogin]);

  // Notificações (somente app instalado): permissão + abrir a confirmação ao tocar no lembrete
  useEffect(() => {
    if (!session || !NOTIFICATIONS_SUPPORTED) return;
    setupNotifications().catch(() => {});

    const open = (response: Notifications.NotificationResponse | null) => {
      if (!response) return;
      const requestId = response.notification.request.identifier + response.notification.date;
      const tripId = response.notification.request.content.data?.tripId as string | undefined;
      if (!tripId || handledNotifications.has(requestId)) return;
      handledNotifications.add(requestId);
      router.push(`/confirm/${tripId}`);
    };

    Notifications.getLastNotificationResponseAsync().then(open).catch(() => {});
    const sub = Notifications.addNotificationResponseReceivedListener(open);
    return () => sub.remove();
  }, [session]);

  if (loading) return <View style={{ flex: 1, backgroundColor: colors.bg }} />;

  return (
    <>
      <StatusBar style={inLogin || isDark ? 'light' : 'dark'} />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="login" />
        <Stack.Screen name="new-trip" options={{ presentation: 'modal' }} />
        <Stack.Screen name="confirm/[id]" options={{ presentation: 'modal' }} />
      </Stack>
      <WebAlertHost />
    </>
  );
}

/** No navegador, mantém o layout de celular centralizado em telas grandes. */
function WebFrame({ children }: { children: React.ReactNode }) {
  const { colors } = useTheme();
  if (Platform.OS !== 'web') return <>{children}</>;
  return (
    <View style={{ flex: 1, backgroundColor: '#0C0912' }}>
      <View style={{ flex: 1, width: '100%', maxWidth: 520, alignSelf: 'center', backgroundColor: colors.bg }}>{children}</View>
    </View>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AuthProvider>
          <WebFrame>
            <Gate />
          </WebFrame>
        </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
