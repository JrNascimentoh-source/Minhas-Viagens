# Minhas Viagens

App (Android e iPhone) para anotar viagens, confirmar conclusão e pagamento, ver o calendário e gerar relatório mensal em PDF.

- **Tecnologia:** React Native + Expo (Expo Router) e Supabase (login e banco de dados)
- **Login:** e-mail e senha, ou Google
- **Lembretes:** notificação local a cada 9 horas para cada viagem em aberto
- **Tema:** claro, escuro ou automático (segue o sistema)

## 1. Instalar e configurar

Requisitos: Node.js (versão LTS) e Git.

```bash
git clone https://github.com/SEU_USUARIO/minhas-viagens.git
cd minhas-viagens
npm install --legacy-peer-deps
npx expo install --fix
```

O `package.json` deixa a maioria das bibliotecas sem versão fixa. O comando `npx expo install --fix` ajusta todas para as versões compatíveis com o Expo SDK do projeto. Rode-o sempre que atualizar o Expo.

Crie o arquivo `.env` a partir do exemplo e preencha com os dados do seu projeto Supabase (Project Settings > API):

```bash
cp .env.example .env
```

```
EXPO_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
EXPO_PUBLIC_SUPABASE_KEY=sb_publishable_SUA_CHAVE
```

Nunca coloque no app a chave `service_role` nem a senha do banco. Use somente a chave publishable (ou anon).

> **Plano B:** se `npm install` der conflito de versões, crie um projeto novo com `npx create-expo-app@latest`, copie para ele as pastas `app/`, `src/`, `assets/`, `supabase/` e o `app.json`, e instale as bibliotecas com `npx expo install` (lista no `package.json`).

## 2. Banco de dados (Supabase)

O SQL da tabela `trips` e das regras de segurança (cada usuário só vê as próprias viagens) está em `supabase/migrations/`. Se for usar outro projeto Supabase, execute esse arquivo no SQL Editor.

### Login com Google

1. No [Google Cloud Console](https://console.cloud.google.com/), crie um projeto e configure a **tela de consentimento OAuth**.
2. Em **APIs e serviços > Credenciais > Criar credenciais > ID do cliente OAuth**, escolha **Aplicativo da Web**.
3. Em **URIs de redirecionamento autorizados**, adicione: `https://SEU-PROJETO.supabase.co/auth/v1/callback`
4. Copie o **Client ID** e o **Client Secret**.
5. No Supabase: **Authentication > Providers > Google**. Ative e cole o Client ID e o Secret.
6. Em **Authentication > URL Configuration > Redirect URLs**, adicione:
   - `minhasviagens://**` (app instalado)
   - `exp://**` (somente para testes com Expo Go)

Os nomes dos menus podem variar um pouco, pois os painéis são atualizados com frequência.

### Cadastro por e-mail

Por padrão o Supabase exige confirmar o e-mail após o cadastro. Para testar sem isso, desative em **Authentication > Providers > Email > Confirm email**.

## 3. Rodar o app

```bash
npx expo start
```

Para testar **notificações** e o **login com Google**, use um *development build* e não o Expo Go:

```bash
npx expo run:android     # precisa do Android Studio
npx expo run:ios         # só em Mac, precisa do Xcode
```

Para instalar em iPhone físico é necessária uma conta Apple.

## 4. Gerar o aplicativo instalável (APK) sem computador

O build é feito na nuvem da Expo (EAS Build), então funciona a partir do Codespaces do GitHub, aberto no navegador do celular.

1. Crie uma conta gratuita em [expo.dev](https://expo.dev). Confira lá o limite de builds do plano gratuito.
2. No terminal do Codespaces, dentro do projeto:

```bash
npm install
npx expo install --fix
npx tsc --noEmit
npm install -g eas-cli
eas login
eas init
eas build --platform android --profile preview
```

3. Ao terminar, o EAS mostra um link e um QR code. Abra o link no celular Android, baixe o `.apk` e instale (o Android pede para permitir instalação de fontes desconhecidas).

O perfil `preview` do `eas.json` gera um APK para instalar direto. Ele já traz a URL e a chave **publishable** do Supabase, que são públicas por definição. Nunca coloque no `eas.json` a chave `service_role` nem a senha do banco.

Para iPhone é necessária uma conta Apple Developer. Para publicar na Play Store, use o perfil `production`, que gera um arquivo `.aab`.

O comando `npx tsc --noEmit` confere erros de TypeScript antes de gastar um build.

## 5. Versão web (abrir no navegador)

O mesmo código roda no navegador. Para testar, no terminal do projeto:

```bash
npm run web
```

No Codespaces, o GitHub abre um aviso com o link da porta 8081. Para publicar um endereço na internet:

1. Entre em [vercel.com](https://vercel.com) com a sua conta do GitHub e importe o repositório `minhas-viagens` (**Add New > Project**). O `vercel.json` já define o comando de build e a pasta de saída.
2. Em **Environment Variables**, cadastre `EXPO_PUBLIC_SUPABASE_URL` e `EXPO_PUBLIC_SUPABASE_KEY` com os mesmos valores do `.env`.
3. Clique em **Deploy**. Ao final você recebe um endereço `https://...vercel.app`.
4. No Supabase, em **Authentication > URL Configuration**, defina o **Site URL** com esse endereço e adicione em **Redirect URLs**: `https://SEU-SITE.vercel.app/**` e, para testes locais, `http://localhost:8081/**`. Sem isso o login com Google não volta para o site.

Netlify também funciona: comando de build `npx expo export --platform web`, pasta de publicação `dist`. O arquivo `public/_redirects` já está incluído. Confira os limites do plano gratuito de cada serviço antes de publicar.

Diferenças da versão web:

| Recurso | No navegador |
|---|---|
| Lembrete a cada 9 h | **Não existe.** Só funciona no app instalado (Android e iPhone). No navegador, confirme as viagens pela tela Início. |
| Relatório em PDF | Abre uma janela de impressão. Escolha **Salvar como PDF**. O navegador precisa permitir pop-ups. |
| Login com Google | A página redireciona para o Google e volta. |
| Layout | Fica no formato de celular, centralizado, em telas grandes. |

## Como o app funciona

| Etapa | O que acontece |
|---|---|
| Nova viagem | Você informa dia, valor e descrição. O app grava a hora de saída, a data e o período (manhã, tarde, noite). A viagem fica **em aberto**. |
| Lembrete | Um aviso a cada 9 h pergunta se a viagem foi concluída e se já foi paga. Tocar no aviso abre a tela de confirmação. |
| Confirmação | Só depois de confirmar que foi concluída a viagem vai para o **registro**. Se disser "ainda não", o lembrete continua. |
| Calendário | Mostra dias trabalhados, sem viagem, em aberto e futuros. Tocar em uma viagem permite confirmar, marcar como paga ou excluir. |
| Relatório | Dias trabalhados, dias não trabalhados e total recebido do mês (viagens concluídas **e pagas**), em PDF para compartilhar. |

## Estrutura

```
app/            telas (Expo Router): login, abas, nova viagem, confirmação
src/lib/        Supabase, viagens, datas, notificações, PDF
src/components/ barra de navegação, rosca, componentes de UI
src/theme/      tema claro/escuro/automático
src/auth/       sessão e login com Google
assets/         ícone do app (iOS, Android, splash, favicon)
supabase/       SQL do banco
```
